from zcore.core import *
print("OK")
