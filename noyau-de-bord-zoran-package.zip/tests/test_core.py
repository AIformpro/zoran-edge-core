from zcore.core import ZoranEdgeCore
def test_register():
    z = ZoranEdgeCore()
    assert "Service enregistré" in z.register("telemetry")
