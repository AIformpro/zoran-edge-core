class ZoranEdgeCore:
    def __init__(self):
        self.services = []
    def register(self, service):
        self.services.append(service)
        return f"Service enregistré: {service}"
    def status(self):
        return {"services": len(self.services)}
